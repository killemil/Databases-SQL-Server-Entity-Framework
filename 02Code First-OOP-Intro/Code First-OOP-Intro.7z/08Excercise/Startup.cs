﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08Excercise
{
    class Startup
    {
        static void Main(string[] args)
        {
            var user = new User()
            {
                Age = 12,
                Email = "emil@abv.bg",
                IsDeleted = false,
                Username = "Elmo",
                Password = "Passw0rd$",
                RegisteredOn = new DateTime(2005, 12, 12)
            };

            Console.WriteLine($"{user.Username} {user.Password} { user.Email}");
        }
    }
}
