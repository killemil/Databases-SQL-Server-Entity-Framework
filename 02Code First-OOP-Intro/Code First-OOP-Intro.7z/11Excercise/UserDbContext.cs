namespace _11Excercise
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class UserDbContext : DbContext
    {
        public UserDbContext()
            : base("name=UserDbContext")
        {
        }
        public virtual DbSet<User> Users { get; set; }

    }
}