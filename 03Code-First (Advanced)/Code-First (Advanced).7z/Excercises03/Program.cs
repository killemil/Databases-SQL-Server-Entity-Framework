﻿namespace Excercises03
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Models;
    class Program
    {
        static void Main(string[] args)
        {
            var context = new SalesDbContext();
            context.Database.Initialize(true);
        }
    }
}
