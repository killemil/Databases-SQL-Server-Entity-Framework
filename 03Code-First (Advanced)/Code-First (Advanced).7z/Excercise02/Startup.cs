﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excercise02
{
    class Startup
    {
        static void Main(string[] args)
        {
            var context = new LocalStoreContext();
            context.Database.Initialize(true);
        }
    }
}
