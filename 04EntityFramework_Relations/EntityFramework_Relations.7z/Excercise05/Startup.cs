﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excercise05.Models;
using System.Data.Entity.Validation;

namespace Excercise05
{
    class Startup
    {
        static void Main(string[] args)
        {
            PhotoDbContext context = new PhotoDbContext();

            Console.WriteLine(context.Photographers.Count());

            // 08 Excercise ---------

           /* Tag tag = new Tag()
            {
                Name = "tag of the tags 432894-320923-493423"
            };

            context.Tags.Add(tag);

            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException)
            {
                tag.Name = TagTransformer.Transform(tag.Name);

                context.SaveChanges();
            }
            */
        }
    }
}
